import zoo as menagerie
menagerie.hours()
