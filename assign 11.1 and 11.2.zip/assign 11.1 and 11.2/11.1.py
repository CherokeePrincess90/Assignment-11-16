import zoo
zoo.hours()
